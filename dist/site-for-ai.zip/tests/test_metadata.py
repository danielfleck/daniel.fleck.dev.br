import unittest
from scripts.site_utils import scan_content, tag_slug
class MetadataTests(unittest.TestCase):
    def test_content_has_unique_keys(self):
        items=scan_content(); keys=[(x.type,x.slug) for x in items]; self.assertEqual(len(keys),len(set(keys)))
    def test_content_required_fields(self):
        for x in scan_content():
            self.assertTrue(x.title); self.assertTrue(x.summary); self.assertTrue(x.published); self.assertTrue(x.tags)
    def test_tag_slugs_do_not_collide(self):
        seen={}
        for x in scan_content():
            for tag in x.tags:
                slug=tag_slug(tag)
                if slug in seen: self.assertEqual(seen[slug],tag)
                seen[slug]=tag
if __name__=='__main__': unittest.main()
