import subprocess,sys,unittest
from scripts.site_utils import ROOT
class BuildTests(unittest.TestCase):
    def test_rebuild_is_idempotent(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/rebuild.py'),'--check'],cwd=ROOT)
        self.assertEqual(p.returncode,0)
    def test_validate(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/validate.py')],cwd=ROOT)
        self.assertEqual(p.returncode,0)
if __name__=='__main__': unittest.main()
