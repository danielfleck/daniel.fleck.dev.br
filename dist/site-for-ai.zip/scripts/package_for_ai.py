from pathlib import Path
import zipfile, shutil
ROOT=Path(__file__).resolve().parents[1]; DIST=ROOT/'dist'; DIST.mkdir(exist_ok=True)
index=DIST/'AI_INDEX.md'
items=[]
for p in sorted(ROOT.rglob('*')):
    rel=p.relative_to(ROOT)
    if any(part in {'.git','.venv','dist','__pycache__'} for part in rel.parts): continue
    if p.is_file(): items.append(str(rel))
index.write_text('# Pacote para análise por IA\n\nForneça este ZIP a uma IA quando ela não conseguir varrer o repositório completo.\n\n## Arquivos\n\n'+'\n'.join(f'- `{x}`' for x in items)+'\n',encoding='utf-8')
zip_path=DIST/'site-for-ai.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if any(part in {'.git','.venv','dist','__pycache__'} for part in rel.parts): continue
        if p.is_file(): z.write(p,rel)
    z.write(index,index.relative_to(ROOT))
print(zip_path)
