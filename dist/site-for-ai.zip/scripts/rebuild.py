from __future__ import annotations
from pathlib import Path
from html import escape
from collections import Counter, defaultdict
import argparse, json, re, shutil, sys

from site_utils import ROOT, scan_content, replace_region, html_tags, tag_slug
from site_config import BASE_URL, AUTHOR

NAV = (ROOT/'templates/partials/nav.html').read_text(encoding='utf-8').strip()
FOOTER = (ROOT/'templates/partials/footer.html').read_text(encoding='utf-8').strip()
STATIC_WITH_PARTIALS = [ROOT/'index.html',ROOT/'blog/index.html',ROOT/'portfolio/index.html',ROOT/'erros/index.html',ROOT/'roadmap/index.html',ROOT/'ferramentas/index.html',ROOT/'privacidade/index.html',ROOT/'termos/index.html',ROOT/'404.html']

class Writer:
    def __init__(self, write=True): self.write=write; self.changed=[]
    def put(self,path:Path,text:str):
        old=path.read_text(encoding='utf-8') if path.exists() else None
        if old!=text:
            self.changed.append(path)
            if self.write:
                path.parent.mkdir(parents=True,exist_ok=True); path.write_text(text,encoding='utf-8')

def card(item):
    type_label={'blog':'Blog','portfolio':'Portfólio','error':'Erro conhecido'}[item.type]
    meta=item.display_date
    if item.type=='error' and item.status: meta=f'{item.status} • {item.display_date}'
    return (f'<article class="card listing-card"><div class="type-label">{escape(type_label)} • {escape(meta)}</div>'
            f'<h2><a href="{item.url}">{escape(item.title)}</a></h2><p>{escape(item.summary)}</p>'
            f'<div class="tag-row">{html_tags(item.tags)}</div><div class="project-links"><a class="project-link" href="{item.url}">Abrir conteúdo</a></div></article>')

def seo_block(item):
    schema={'blog':'BlogPosting','portfolio':'CreativeWork','error':'TechArticle'}[item.type]
    url=BASE_URL+item.url
    data={'@context':'https://schema.org','@type':schema,'headline':item.title,'name':item.title,'description':item.summary,'url':url,'datePublished':item.published,'dateModified':item.published,'inLanguage':'pt-BR','keywords':list(item.tags),'author':{'@type':'Person','name':AUTHOR,'url':BASE_URL+'/'}}
    if item.type=='blog': data['articleSection']=item.category
    if item.type=='error': data['articleSection']='Base de Conhecimento — Erros e Soluções'
    js=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    return (f'<title>{escape(item.title)} | Daniel Fleck</title><meta name="description" content="{escape(item.summary,quote=True)}">'
            f'<link rel="canonical" href="{url}"><meta property="og:type" content="article"><meta property="og:title" content="{escape(item.title,quote=True)}">'
            f'<meta property="og:description" content="{escape(item.summary,quote=True)}"><meta property="og:url" content="{url}"><script type="application/ld+json">{js}</script>')

def header_block(item):
    label={'blog':item.category,'portfolio':'Portfólio','error':'Erro conhecido'}[item.type]
    status=f'<span class="tag success">{escape(item.status)}</span>' if item.status else ''
    return (f'<header class="page-header"><div class="article-meta"><span class="tag brand">{escape(label)}</span>{status}<span class="tag">{escape(item.display_date)}</span></div>'
            f'<h1>{escape(item.title)}</h1><p class="page-summary">{escape(item.summary)}</p><div class="tag-row">{html_tags(item.tags)}</div></header>')

def links_block(item):
    return '<div class="content-actions"><a href="/'+item.section+'/">← Voltar ao índice</a><a href="/tags/">Explorar tags</a></div>'

def tag_cloud(items):
    freq=Counter(t for i in items for t in i.tags)
    if not freq: return '<div class="word-cloud"></div>'
    mn,mx=min(freq.values()),max(freq.values())
    colors=['blue','teal','orange','muted']
    parts=[]
    for idx,(tag,count) in enumerate(sorted(freq.items(),key=lambda kv:(-kv[1],kv[0].casefold()))):
        ratio=.5 if mx==mn else (count-mn)/(mx-mn)
        size=11+ratio*9
        parts.append(f'<a class="word-cloud-item {colors[idx%len(colors)]}" href="/tags/{tag_slug(tag)}/" title="{escape(tag,quote=True)} — {count} ocorrência(s)" style="font-size:{size:.1f}px">{escape(tag)}</a>')
    return '<div class="word-cloud" aria-label="Nuvem de tags">'+''.join(parts)+'</div>'

def tag_page(tag, members):
    groups=defaultdict(list)
    for i in members: groups[i.type].append(i)
    sections=[]
    labels={'blog':'Blog','portfolio':'Portfólio','error':'Erros e soluções'}
    for k in ('blog','portfolio','error'):
        if groups[k]: sections.append(f'<section class="tag-page-group"><h2>{labels[k]}</h2><div class="listing-grid">'+''.join(card(i) for i in sorted(groups[k],key=lambda x:x.published,reverse=True))+'</div></section>')
    url=f'{BASE_URL}/tags/{tag_slug(tag)}/'
    nav=(ROOT/'templates/partials/nav.html').read_text(encoding='utf-8').strip(); footer=(ROOT/'templates/partials/footer.html').read_text(encoding='utf-8').strip()
    return f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self'; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'; upgrade-insecure-requests"><title>{escape(tag)} | Tags | Daniel Fleck</title><meta name="description" content="Conteúdos relacionados à tag {escape(tag,quote=True)}."><link rel="canonical" href="{url}"><link rel="stylesheet" href="/css/base.css"><link rel="stylesheet" href="/css/layout.css"><link rel="stylesheet" href="/css/components.css"><link rel="stylesheet" href="/css/pages.css"><script src="/js/main.js" defer></script></head><body><!-- GENERATED-TAG-PAGE: não editar manualmente. Fonte: CONTENT-META das páginas. -->{nav}<main class="container"><section class="section"><header class="page-header"><div class="section-kicker">Tag</div><h1>{escape(tag)}</h1><p class="page-summary">{len(members)} conteúdo(s) relacionado(s).</p></header>{''.join(sections)}</section></main>{footer}</body></html>'''

def tag_index(items):
    nav=(ROOT/'templates/partials/nav.html').read_text(encoding='utf-8').strip(); footer=(ROOT/'templates/partials/footer.html').read_text(encoding='utf-8').strip(); cloud=tag_cloud(items)
    return f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self'; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'; upgrade-insecure-requests"><title>Tags | Daniel Fleck</title><meta name="description" content="Índice de tags do conteúdo técnico."><link rel="canonical" href="{BASE_URL}/tags/"><link rel="stylesheet" href="/css/base.css"><link rel="stylesheet" href="/css/layout.css"><link rel="stylesheet" href="/css/components.css"><link rel="stylesheet" href="/css/pages.css"><script src="/js/main.js" defer></script></head><body><!-- GENERATED-TAG-PAGE: não editar manualmente. -->{nav}<main class="container"><section class="section"><header class="page-header"><div class="section-kicker">Descoberta de conteúdo</div><h1>Tags</h1><p class="page-summary">A nuvem considera blog, portfólio e Base de Conhecimento — Erros e Soluções.</p></header>{cloud}</section></main>{footer}</body></html>'''

def apply_partials(text):
    if '<!-- GENERATED:SITE-NAV:START -->' in text: text=replace_region(text,'SITE-NAV',NAV)
    if '<!-- GENERATED:SITE-FOOTER:START -->' in text: text=replace_region(text,'SITE-FOOTER',FOOTER)
    return text

def build(write=True):
    w=Writer(write); items=scan_content(ROOT)
    # Content pages
    for item in items:
        text=item.path.read_text(encoding='utf-8'); text=apply_partials(text); text=replace_region(text,'SEO',seo_block(item)); text=replace_region(text,'ARTICLE-HEADER',header_block(item)); text=replace_region(text,'CONTENT-LINKS',links_block(item)); w.put(item.path,text)
    # Shared partials on static pages
    for p in STATIC_WITH_PARTIALS:
        if p.exists(): w.put(p,apply_partials(p.read_text(encoding='utf-8')))
    # Index lists
    sorted_items=sorted(items,key=lambda x:(x.published,x.title),reverse=True)
    bytype={k:[i for i in sorted_items if i.type==k] for k in ('blog','portfolio','error')}
    specs=[(ROOT/'blog/index.html','BLOG-LIST',bytype['blog']),(ROOT/'portfolio/index.html','PORTFOLIO-LIST',bytype['portfolio']),(ROOT/'erros/index.html','ERROS-LIST',bytype['error'])]
    for path,region,vals in specs:
        text=path.read_text(encoding='utf-8'); inner='<div class="listing-grid">'+''.join(card(i) for i in vals)+'</div>'; w.put(path,replace_region(text,region,inner))
    # Home generated regions
    home=(ROOT/'index.html').read_text(encoding='utf-8')
    featured=[i for i in bytype['portfolio'] if i.featured][:4]
    home=replace_region(home,'HOME-PORTFOLIO','<div class="home-evidence-grid">'+''.join(card(i) for i in featured)+'</div>')
    home=replace_region(home,'HOME-BLOG','<div class="listing-grid">'+''.join(card(i) for i in bytype['blog'][:4])+'</div>')
    home=replace_region(home,'HOME-ERRORS','<div class="listing-grid">'+''.join(card(i) for i in bytype['error'][:3])+'</div>')
    home=replace_region(home,'TAG-CLOUD',tag_cloud(items)); w.put(ROOT/'index.html',home)
    # Tags
    tags=defaultdict(list)
    for i in items:
        for t in i.tags: tags[t].append(i)
    desired={tag_slug(t):t for t in tags}
    tags_root=ROOT/'tags'; tags_root.mkdir(exist_ok=True)
    for child in tags_root.iterdir():
        if child.is_dir() and (child/'index.html').exists():
            existing=(child/'index.html').read_text(encoding='utf-8')
            if 'GENERATED-TAG-PAGE' in existing and child.name not in desired:
                w.changed.append(child)
                if write: shutil.rmtree(child)
    for slug,t in desired.items(): w.put(tags_root/slug/'index.html',tag_page(t,tags[t]))
    w.put(tags_root/'index.html',tag_index(items))
    # Sitemap
    urls=[BASE_URL+'/',BASE_URL+'/curriculo.html',BASE_URL+'/blog/',BASE_URL+'/portfolio/',BASE_URL+'/erros/',BASE_URL+'/tags/',BASE_URL+'/roadmap/',BASE_URL+'/ferramentas/',BASE_URL+'/privacidade/',BASE_URL+'/termos/']
    urls += [BASE_URL+i.url for i in items]
    urls += [f'{BASE_URL}/tags/{slug}/' for slug in sorted(desired)]
    sm='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join(f'  <url><loc>{escape(u)}</loc></url>\n' for u in urls)+'</urlset>\n'
    w.put(ROOT/'sitemap.xml',sm)
    robots=f'User-agent: *\nAllow: /\nSitemap: {BASE_URL}/sitemap.xml\n'; w.put(ROOT/'robots.txt',robots)
    return w.changed

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--check',action='store_true'); ap.add_argument('--hook',action='store_true'); args=ap.parse_args()
    changed=build(write=not args.check)
    if changed:
        print('Arquivos que exigem rebuild/atualização:')
        for p in changed: print(' -', p.relative_to(ROOT) if p.exists() or p.is_absolute() else p)
        if args.check: return 2
        if args.hook:
            print('\nO rebuild foi executado pelo hook e alterou arquivos gerados. Revise, faça git add e repita o commit.')
            return 3
    else: print('Rebuild: nenhum arquivo gerado precisou ser alterado.')
    return 0
if __name__=='__main__': raise SystemExit(main())
