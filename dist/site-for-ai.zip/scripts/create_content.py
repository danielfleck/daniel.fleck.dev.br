from __future__ import annotations
from pathlib import Path
from datetime import date
import argparse, subprocess, sys
from site_utils import ROOT, slugify

TYPE_MAP={'blog':('blog','blog.html'),'portfolio':('portfolio','portfolio.html'),'erro':('erros','erro.html')}
MONTHS=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
def display_date(iso):
    y,m,d=iso.split('-'); return f'{d} {MONTHS[int(m)-1]} {y}'
def ask(label,default=''):
    suffix=f' [{default}]' if default else ''
    value=input(f'{label}{suffix}: ').strip(); return value or default

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('tipo',choices=TYPE_MAP); args=ap.parse_args()
    section,template_name=TYPE_MAP[args.tipo]
    title=ask('Título');
    if not title: raise SystemExit('Título obrigatório.')
    summary=ask('Resumo');
    if not summary: raise SystemExit('Resumo obrigatório.')
    published=ask('Data ISO (AAAA-MM-DD)',date.today().isoformat())
    try:
        date.fromisoformat(published)
    except ValueError:
        raise SystemExit('Data inválida. Use AAAA-MM-DD, por exemplo 2026-08-10.')
    slug=slugify(ask('Slug',slugify(title)))
    category=ask('Categoria', {'blog':'Técnico','portfolio':'Portfólio','erro':'Troubleshooting'}[args.tipo])
    status=ask('Status','Resolvido') if args.tipo=='erro' else ''
    tags=ask('Tags separadas por vírgula')
    tag_values=[t.strip() for t in tags.split(',') if t.strip()]
    if not tag_values: raise SystemExit('Informe pelo menos uma tag.')
    raw_values=[title,summary,category,status,*tag_values]
    if any('\n' in value or '\r' in value or '-->' in value for value in raw_values):
        raise SystemExit('Metadados não podem conter quebra de linha nem a sequência -->.')
    target=ROOT/section/slug/'index.html'
    if target.exists(): raise SystemExit(f'Slug já existe: {target.relative_to(ROOT)}')
    template=(ROOT/'templates'/template_name).read_text(encoding='utf-8')
    featured='false'
    if args.tipo=='portfolio':
        featured='true' if ask('Destacar na página inicial? (s/n)','n').lower() in {'s','sim','y','yes'} else 'false'
    replacements={'{{TITLE}}':title,'{{SUMMARY}}':summary,'{{PUBLISHED}}':published,'{{DISPLAY_DATE}}':display_date(published),'{{SLUG}}':slug,'{{CATEGORY}}':category,'{{STATUS}}':status,'{{FEATURED}}':featured,'{{TAGS}}':' | '.join(tag_values)}
    for k,v in replacements.items(): template=template.replace(k,v)
    target.parent.mkdir(parents=True,exist_ok=True); target.write_text(template,encoding='utf-8')
    print('Criado:',target.relative_to(ROOT))
    subprocess.run([sys.executable,str(ROOT/'scripts/rebuild.py')],cwd=ROOT,check=True)
    print('Edite somente o corpo entre CONTENT-BODY:START e CONTENT-BODY:END e execute novamente python scripts/rebuild.py.')
if __name__=='__main__': main()
