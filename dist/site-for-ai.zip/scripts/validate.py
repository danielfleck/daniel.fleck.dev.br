from __future__ import annotations
from pathlib import Path
import json, re, subprocess, sys, xml.etree.ElementTree as ET
from site_utils import ROOT, scan_content, tag_slug, resolve_local_target

HTML_ATTR_RE=re.compile(r'(?:href|src)=["\']([^"\']+)["\']',re.I)
JSON_LD_RE=re.compile(r'<script\s+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',re.I|re.S)
AUTO_EXTERNAL_RE=[
    re.compile(r'<script[^>]+src=["\']https?://',re.I),
    re.compile(r'<img[^>]+src=["\']https?://',re.I),
    re.compile(r'<iframe[^>]+src=["\']https?://',re.I),
    re.compile(r'<link[^>]+rel=["\']stylesheet["\'][^>]+href=["\']https?://',re.I),
]

def public_html_files():
    for path in ROOT.rglob('*.html'):
        if any(part in {'.venv','dist','.git','templates'} for part in path.parts):
            continue
        yield path

def main():
    errors=[]; warnings=[]
    try: items=scan_content(ROOT)
    except Exception as e: errors.append(str(e)); items=[]
    seen=set(); tagslug={}
    for i in items:
        key=(i.type,i.slug)
        if key in seen: errors.append(f'Duplicidade de conteúdo: {key}')
        seen.add(key)
        for field in ('title','summary','published','display_date','category'):
            if not getattr(i,field): errors.append(f'{i.path}: campo {field} vazio')
        if len(i.summary)>220: warnings.append(f'{i.path.relative_to(ROOT)}: resumo longo ({len(i.summary)} caracteres)')
        if not i.tags: errors.append(f'{i.path}: nenhuma tag')
        for t in i.tags:
            s=tag_slug(t)
            if s in tagslug and tagslug[s]!=t: errors.append(f'Colisão de slug de tag: {tagslug[s]!r} x {t!r} -> {s}')
            tagslug[s]=t
        page=i.path.read_text(encoding='utf-8')
        for marker in ('CONTENT-META','CONTENT-BODY:START','CONTENT-BODY:END','AI-CONTENT-MAINTENANCE'):
            if marker not in page: errors.append(f'{i.path.relative_to(ROOT)}: marcador/instrução ausente: {marker}')

    canonicals={}
    for path in public_html_files():
        text=path.read_text(encoding='utf-8')
        rel=path.relative_to(ROOT)
        if path in (ROOT/'blog/index.html', ROOT/'portfolio/index.html', ROOT/'erros/index.html') and 'GENERATED:' not in text:
            errors.append(f'Marcadores de geração ausentes em {rel}')
        if re.search(r'\{\{[A-Z_]+\}\}', text):
            errors.append(f'Placeholder de template não resolvido: {rel}')
        if '<h1' not in text.lower(): errors.append(f'H1 ausente: {rel}')
        if text.lower().count('<title>')!=1: errors.append(f'{rel}: esperado exatamente 1 <title>')
        canonical_matches=re.findall(r'<link\s+rel=["\']canonical["\']\s+href=["\']([^"\']+)["\']',text,re.I)
        if len(canonical_matches)!=1:
            errors.append(f'{rel}: esperado exatamente 1 canonical; encontrados {len(canonical_matches)}')
        else:
            canonical=canonical_matches[0]
            if canonical in canonicals: errors.append(f'Canonical duplicado: {rel} e {canonicals[canonical]} -> {canonical}')
            canonicals[canonical]=rel
        if len(re.findall(r'<meta\s+name=["\']description["\']',text,re.I))!=1:
            errors.append(f'{rel}: esperado exatamente 1 meta description')
        if 'AI-MAINTENANCE' not in text and 'AI-LEGAL-MAINTENANCE' not in text and 'GENERATED-TAG-PAGE' not in text:
            errors.append(f'{rel}: instrução de manutenção por IA ausente')
        for raw in JSON_LD_RE.findall(text):
            try: json.loads(raw)
            except Exception as e: errors.append(f'JSON-LD inválido em {rel}: {e}')
        for ref in HTML_ATTR_RE.findall(text):
            target=resolve_local_target(path,ref,ROOT)
            if target is not None and not target.exists(): errors.append(f'Link/recurso local inexistente: {rel} -> {ref}')
        if any(rx.search(text) for rx in AUTO_EXTERNAL_RE): errors.append(f'Recurso externo automático: {rel}')
        if 'data:image' in text.lower(): errors.append(f'Imagem base64/data URI: {rel}')

    # Sitemap: XML válido, URLs únicas e conjunto esperado (exceto 404, que não deve ser indexada).
    try:
        tree=ET.parse(ROOT/'sitemap.xml'); ns={'s':'http://www.sitemaps.org/schemas/sitemap/0.9'}
        locs=[e.text for e in tree.findall('.//s:loc',ns) if e.text]
        if len(locs)!=len(set(locs)): errors.append('sitemap.xml possui URLs duplicadas')
        expected=set(canonicals)
        expected.discard('https://daniel.fleck.dev.br/404.html')
        missing=expected-set(locs); extra=set(locs)-expected
        if missing: errors.append('sitemap.xml sem URLs canônicas: '+', '.join(sorted(missing)))
        if extra: errors.append('sitemap.xml possui URLs sem página canônica correspondente: '+', '.join(sorted(extra)))
    except Exception as e:
        errors.append(f'sitemap.xml inválido: {e}')

    proc=subprocess.run([sys.executable,str(ROOT/'scripts/rebuild.py'),'--check'],cwd=ROOT,capture_output=True,text=True)
    if proc.returncode!=0: errors.append('Arquivos gerados estão desatualizados. Execute python scripts/rebuild.py.')
    if errors:
        print('VALIDAÇÃO FALHOU')
        for e in errors: print('ERROR:',e)
        for w in warnings: print('WARN:',w)
        return 1
    print(f'VALIDAÇÃO OK: {len(items)} conteúdos, {len(tagslug)} tags e links/SEO locais consistentes.')
    for w in warnings: print('WARN:',w)
    return 0
if __name__=='__main__': raise SystemExit(main())
