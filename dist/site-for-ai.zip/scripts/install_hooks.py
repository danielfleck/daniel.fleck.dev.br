from pathlib import Path
import os, subprocess
ROOT=Path(__file__).resolve().parents[1]
hook=ROOT/'.githooks/pre-commit'
hook.chmod(hook.stat().st_mode | 0o111)
subprocess.run(['git','config','core.hooksPath','.githooks'],cwd=ROOT,check=True)
print('Git configurado para usar .githooks/. O pre-commit executará rebuild e validação.')
