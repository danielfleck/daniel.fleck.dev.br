from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from html import escape
from urllib.parse import urlparse, unquote
import re, unicodedata

ROOT = Path(__file__).resolve().parents[1]
META_RE = re.compile(r'<!--\s*CONTENT-META\s*(.*?)-->', re.S)

@dataclass(frozen=True)
class ContentMeta:
    type: str
    slug: str
    title: str
    summary: str
    published: str
    display_date: str
    category: str
    status: str
    featured: bool
    tags: tuple[str, ...]
    path: Path

    @property
    def section(self) -> str:
        return {'blog':'blog','portfolio':'portfolio','error':'erros'}[self.type]

    @property
    def url(self) -> str:
        return f'/{self.section}/{self.slug}/'

def slugify(value: str) -> str:
    text = unicodedata.normalize('NFKD', value).encode('ascii','ignore').decode('ascii').lower()
    text = re.sub(r'[^a-z0-9]+','-',text).strip('-')
    return text or 'conteudo'

def parse_meta_text(text: str, path: Path) -> ContentMeta:
    m = META_RE.search(text)
    if not m:
        raise ValueError(f'CONTENT-META ausente: {path}')
    values = {}
    for raw in m.group(1).splitlines():
        line=raw.strip()
        if not line or ':' not in line: continue
        key,val=line.split(':',1)
        values[key.strip()]=val.strip()
    tags=tuple(t.strip() for t in values.get('tags','').split('|') if t.strip())
    return ContentMeta(
        type=values.get('type',''), slug=values.get('slug',''), title=values.get('title',''), summary=values.get('summary',''),
        published=values.get('published',''), display_date=values.get('display_date',''), category=values.get('category',''),
        status=values.get('status',''), featured=values.get('featured','false').lower()=='true', tags=tags, path=path)

def scan_content(root: Path = ROOT) -> list[ContentMeta]:
    items=[]
    for section in ('blog','portfolio','erros'):
        base=root/section
        if not base.exists(): continue
        for path in sorted(base.glob('*/index.html')):
            items.append(parse_meta_text(path.read_text(encoding='utf-8'), path))
    return items

def replace_region(text: str, name: str, inner: str) -> str:
    start=f'<!-- GENERATED:{name}:START -->'
    end=f'<!-- GENERATED:{name}:END -->'
    if start not in text or end not in text:
        raise ValueError(f'Marcadores {name} ausentes')
    before,rest=text.split(start,1)
    _,after=rest.split(end,1)
    return before+start+inner+end+after

def tag_slug(tag: str) -> str:
    return slugify(tag)

def html_tags(tags) -> str:
    return ''.join(f'<a class="tag" href="/tags/{tag_slug(t)}/">{escape(t)}</a>' for t in tags)

def resolve_local_target(page: Path, href: str, root: Path = ROOT) -> Path | None:
    if not href or href.startswith(('#','mailto:','tel:','javascript:')): return None
    parsed=urlparse(href)
    if parsed.scheme in ('http','https'): return None
    raw=unquote(parsed.path)
    if raw.startswith('/'):
        rel=raw.lstrip('/')
        target=root/rel
    else:
        target=(page.parent/raw).resolve()
    if raw.endswith('/') or target.is_dir(): target=target/'index.html'
    return target
